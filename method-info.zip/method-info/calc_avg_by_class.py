"""
calc_avg_by_class.py
Scan the LLM4Cpp/ folder for function_info JSON files and compute average
`tokenUsedForContext` per class (determined by the immediate parent folder name, substring before the first '_').

Place this script in the repository root. By default it will scan the sibling
`LLM4Cpp/` folder (i.e. ./LLM4Cpp relative to this script).

Usage:
    python calc_avg_by_class.py --root PATH [--pattern GLOB] [--csv OUT.csv] [--verbose]

Defaults:
    root: ./LLM4Cpp (relative to the script location)
    pattern: function_info_*.json
"""

import argparse
import os
import json
import fnmatch
import re
import csv
import sys
from collections import defaultdict

TOKEN_RE = re.compile(r'"tokenUsedForContext"\s*:\s*(\d+)', re.IGNORECASE)


def find_files(root, pattern):
    matches = []
    for dirpath, dirnames, filenames in os.walk(root):
        for name in filenames:
            if fnmatch.fnmatch(name, pattern):
                matches.append(os.path.join(dirpath, name))
    return matches


def parse_file_for_tokens(path, verbose=False):
    tokens = []
    try:
        with open(path, 'r', encoding='utf-8', errors='ignore') as f:
            text = f.read()
    except Exception as e:
        if verbose:
            print(f"[WARN] Failed to read {path}: {e}")
        return tokens

    # Try JSON parse
    try:
        parsed = json.loads(text)
    except Exception:
        parsed = None

    if parsed is not None:
        if isinstance(parsed, dict):
            # direct key
            if 'tokenUsedForContext' in parsed:
                try:
                    tokens.append(int(parsed['tokenUsedForContext']))
                except Exception:
                    pass
            else:
                # nested values possibly
                for v in parsed.values():
                    if isinstance(v, dict) and 'tokenUsedForContext' in v:
                        try:
                            tokens.append(int(v['tokenUsedForContext']))
                        except Exception:
                            pass
        elif isinstance(parsed, list):
            for item in parsed:
                if isinstance(item, dict) and 'tokenUsedForContext' in item:
                    try:
                        tokens.append(int(item['tokenUsedForContext']))
                    except Exception:
                        pass
    # regex fallback
    if not tokens:
        for m in TOKEN_RE.finditer(text):
            try:
                tokens.append(int(m.group(1)))
            except Exception:
                continue

    if verbose and not tokens:
        print(f"[INFO] No tokenUsedForContext found in {path}")
    return tokens


def class_from_path(path, root):
    # immediate parent folder of the file
    parent = os.path.basename(os.path.dirname(path))
    if not parent:
        return '__unknown__'
    # class is substring before first '_'
    return parent.split('_', 1)[0]


def aggregate_by_class(root, pattern='function_info_*.json', verbose=False):
    files = find_files(root, pattern)
    per_class = defaultdict(lambda: {'total': 0, 'count': 0, 'files': 0})
    total_tokens = 0
    total_count = 0

    for f in files:
        cls = class_from_path(f, root)
        tokens = parse_file_for_tokens(f, verbose=verbose)
        if not tokens:
            continue
        file_sum = sum(tokens)
        file_count = len(tokens)

        per_class[cls]['total'] += file_sum
        per_class[cls]['count'] += file_count
        per_class[cls]['files'] += 1

        total_tokens += file_sum
        total_count += file_count

        if verbose:
            print(f"[FOUND] {f}: class={cls} sum={file_sum} count={file_count}")

    results = []
    for cls, data in sorted(per_class.items(), key=lambda x: x[0]):
        avg = data['total'] / data['count'] if data['count'] else 0
        results.append({'class': cls, 'total': data['total'], 'count': data['count'], 'average': avg, 'files': data['files']})

    overall_avg = (total_tokens / total_count) if total_count else 0
    return results, {'total_tokens': total_tokens, 'total_count': total_count, 'overall_average': overall_avg}


def write_csv(path, rows):
    with open(path, 'w', newline='', encoding='utf-8') as csvf:
        writer = csv.DictWriter(csvf, fieldnames=['class', 'total', 'count', 'average', 'files'])
        writer.writeheader()
        for r in rows:
            writer.writerow(r)


def print_results(rows, summary):
    print("Class, TotalTokens, Count, Average, Files")
    for r in rows:
        print(f"{r['class']}, {r['total']}, {r['count']}, {r['average']:.2f}, {r['files']}")
    print()
    print(f"Overall: total_tokens={summary['total_tokens']}, total_count={summary['total_count']}, overall_average={summary['overall_average']:.2f}")


def main(argv=None):
    parser = argparse.ArgumentParser(description='Calculate average tokenUsedForContext per class (parent folder before first underscore)')
    parser.add_argument('--root', '-r', default='LLM4Cpp/tinyxml2', help='Root folder to scan (default: LLM4Cpp next to script)')
    parser.add_argument('--pattern', '-p', default='function_info_*.json', help='Filename glob pattern')
    parser.add_argument('--csv', '-c', default=None, help='Write CSV output to this file')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    args = parser.parse_args(argv)

    root = args.root
    if not os.path.isabs(root):
        root = os.path.abspath(os.path.join(os.path.dirname(__file__), root))

    if not os.path.isdir(root):
        print(f"Root folder does not exist: {root}", file=sys.stderr)
        sys.exit(2)

    rows, summary = aggregate_by_class(root, pattern=args.pattern, verbose=args.verbose)
    print_results(rows, summary)

    if args.csv:
        write_csv(args.csv, rows)
        if args.verbose:
            print(f"Wrote CSV to {args.csv}")


if __name__ == '__main__':
    main()

