"""
calc_avg_context.py
Scan the LLM4Cpp/ folder for function_info JSON files and compute average
`tokenUsedForContext` per project (immediate subdirectory under LLM4Cpp).

Place this script in the repository root. By default it will scan the sibling
`LLM4Cpp/` folder (i.e. ./LLM4Cpp relative to this script).

Usage:
    python calc_avg_context.py --root PATH [--pattern GLOB] [--csv OUT.csv] [--verbose]

Defaults:
    root: ./LLM4Cpp (relative to the script location)
    pattern: function_info_*.json

The script is robust: it tries json.loads first, and falls back to a regex search for
"tokenUsedForContext" numeric values when files contain non-JSON prefixes/suffixes.
"""

import argparse
import os
import json
import fnmatch
import re
import csv
import sys
from collections import defaultdict

TOKEN_RE = re.compile(r'"tokenUsedForContext"\s*:\s*(\d+)', re.IGNORECASE)


def find_files(root, pattern):
    matches = []
    for dirpath, dirnames, filenames in os.walk(root):
        for name in filenames:
            if fnmatch.fnmatch(name, pattern):
                matches.append(os.path.join(dirpath, name))
    return matches


def parse_file_for_tokens(path, verbose=False):
    """Return a list of integers found for tokenUsedForContext in the file.

    Strategy:
    - Try to load the entire file with json.loads(). If successful and it's a dict,
      try to read 'tokenUsedForContext'. If it's a list/array, walk elements and
      collect values.
    - If json parsing fails or doesn't find values, fall back to a regex search
      that extracts numeric values for the key name.
    """
    tokens = []
    try:
        text = open(path, 'r', encoding='utf-8', errors='ignore').read()
    except Exception as e:
        if verbose:
            print(f"[WARN] Failed to read {path}: {e}")
        return tokens

    # Attempt JSON parse
    try:
        parsed = json.loads(text)
    except Exception:
        parsed = None

    if parsed is not None:
        # parsed can be dict, list, or other
        if isinstance(parsed, dict):
            if 'tokenUsedForContext' in parsed:
                try:
                    tokens.append(int(parsed['tokenUsedForContext']))
                except Exception:
                    pass
            else:
                # maybe nested or many functions? search dict values
                for v in parsed.values():
                    if isinstance(v, dict) and 'tokenUsedForContext' in v:
                        try:
                            tokens.append(int(v['tokenUsedForContext']))
                        except Exception:
                            pass
        elif isinstance(parsed, list):
            for item in parsed:
                if isinstance(item, dict) and 'tokenUsedForContext' in item:
                    try:
                        tokens.append(int(item['tokenUsedForContext']))
                    except Exception:
                        pass
    # Fallback: regex search for numeric occurrences of the key
    if not tokens:
        for m in TOKEN_RE.finditer(text):
            try:
                tokens.append(int(m.group(1)))
            except Exception:
                continue

    if verbose and not tokens:
        print(f"[INFO] No tokenUsedForContext found in {path}")

    return tokens


def aggregate(root, pattern='function_info_*.json', include_root=False, verbose=False):
    files = find_files(root, pattern)
    per_project = defaultdict(lambda: {'total': 0, 'count': 0, 'files': 0})
    total_tokens = 0
    total_count = 0

    for f in files:
        rel = os.path.relpath(f, root)
        parts = rel.split(os.sep)
        project = parts[0] if len(parts) > 1 else ('__root__' if include_root else None)
        if project is None:
            if verbose:
                print(f"[SKIP] file outside project root: {f}")
            continue

        tokens = parse_file_for_tokens(f, verbose=verbose)
        if not tokens:
            # still count this file as processed (optional)
            continue

        file_sum = sum(tokens)
        file_count = len(tokens)

        per_project[project]['total'] += file_sum
        per_project[project]['count'] += file_count
        per_project[project]['files'] += 1

        total_tokens += file_sum
        total_count += file_count

        if verbose:
            print(f"[FOUND] {f}: sum={file_sum} count={file_count}")

    # compute averages
    results = []
    for proj, data in sorted(per_project.items(), key=lambda x: x[0]):
        avg = data['total'] / data['count'] if data['count'] else 0
        results.append({'project': proj, 'total': data['total'], 'count': data['count'], 'average': avg, 'files': data['files']})

    overall_avg = (total_tokens / total_count) if total_count else 0
    return results, {'total_tokens': total_tokens, 'total_count': total_count, 'overall_average': overall_avg}


def write_csv(path, rows):
    with open(path, 'w', newline='', encoding='utf-8') as csvf:
        writer = csv.DictWriter(csvf, fieldnames=['project', 'total', 'count', 'average', 'files'])
        writer.writeheader()
        for r in rows:
            writer.writerow(r)


def print_results(rows, summary):
    print("Project, TotalTokens, Count, Average, Files")
    for r in rows:
        print(f"{r['project']}, {r['total']}, {r['count']}, {r['average']:.2f}, {r['files']}")
    print()
    print(f"Overall: total_tokens={summary['total_tokens']}, total_count={summary['total_count']}, overall_average={summary['overall_average']:.2f}")


def main(argv=None):
    parser = argparse.ArgumentParser(description='Calculate average tokenUsedForContext per project under LLM4Cpp/')
    parser.add_argument('--root', '-r', default='LLM4Cpp', help='Root folder to scan. Default: LLM4Cpp folder next to this script')
    parser.add_argument('--pattern', '-p', default='function_info_*.json', help='Filename glob pattern to match function info JSON files')
    parser.add_argument('--csv', '-c', default=None, help='Write CSV output to this file')
    parser.add_argument('--include-root', action='store_true', help='Include files directly under the root as project "__root__"')
    parser.add_argument('--verbose', '-v', action='store_true', help='Verbose output')
    args = parser.parse_args(argv)

    # Resolve root relative to script location when not absolute
    root = args.root
    if not os.path.isabs(root):
        root = os.path.abspath(os.path.join(os.path.dirname(__file__), root))

    if not os.path.isdir(root):
        print(f"Root folder does not exist: {root}", file=sys.stderr)
        sys.exit(2)

    rows, summary = aggregate(root, pattern=args.pattern, include_root=args.include_root, verbose=args.verbose)
    print_results(rows, summary)

    if args.csv:
        write_csv(args.csv, rows)
        if args.verbose:
            print(f"Wrote CSV to {args.csv}")


if __name__ == '__main__':
    main()

